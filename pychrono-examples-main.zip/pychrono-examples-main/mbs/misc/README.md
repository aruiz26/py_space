# misc
Folder contains simple multibody systems -- all sorts of odds and ends.
