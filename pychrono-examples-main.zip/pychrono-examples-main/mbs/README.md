# mbs
Folder contains classical multibody systems, e.g., slider crank, double pendulum, four bar mechanism
