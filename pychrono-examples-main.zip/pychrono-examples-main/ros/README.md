# ros
Folder contains basic examples of interfacing a chrono simulation to an autonomy stack via the ROS bridge
