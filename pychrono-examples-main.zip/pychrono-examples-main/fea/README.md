# fea
Folder contains basic examples of flexible body systems.
